void main() {
  int start = 20;
  int end = 30;
  while (start <= end) {
    if (start % 7 == 0) {
      print(start);
    }
    start++;
  }
}
